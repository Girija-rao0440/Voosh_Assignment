package Voosh.Assignment;



import org.openqa.selenium.WebDriver;


import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import java.util.concurrent.TimeUnit;


public class Base {
    protected WebDriver driver;
    protected ExtentReports extent;
    protected ExtentTest test;


    @BeforeMethod
    public void setUp() {
//       
    	 System.setProperty("webdriver.chrome.driver", "C://Users//GIRIJA//Downloads//Driver//chromedriver.exe");

         // Initialize ChromeDriver
          driver = new ChromeDriver();
       
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.amazon.in/");
        
        // Initialize Extent Reports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("test-output/ExtentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
       // extent.flush();
    }
}

