package Voosh.Assignment;

import java.io.IOException;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
public class Home extends Base {
@Test
	 public void testHomeLink() throws IOException  {
	        driver.get("https://www.amazon.in/");
	         test = extent.createTest("Test Home Link");
	      
	        WebElement amazonLogo = driver.findElement(By.id("nav-logo-sprites"));
            amazonLogo.click();
            String expectedHomePageTitle = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
            String actualTitle = driver.getTitle();
            System.out.println(actualTitle);
            Assert.assertEquals(actualTitle, expectedHomePageTitle, "User is not redirected to the Amazon homepage.");
            test.log(Status.INFO, "Clicked on Amazon logo.");
            test.log(Status.PASS, "Home page title verified.");
            // Capture screenshot and log
            String screenshotPath = Screenshotutils.captureScreenshot(driver, "HomeLinkScreenshot");
            test.addScreenCaptureFromPath(screenshotPath);
            test.log(Status.INFO, "Screenshot captured: " + screenshotPath);

            
	 }


}





