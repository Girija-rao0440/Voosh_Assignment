package Voosh.Assignment;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class InvalidSearchTest extends Base{
	
	@Test
    public void testSearchResultsDisplay1() throws IOException {
        driver.get("https://www.amazon.in/");
         test = extent.createTest("Test Invalid search");
        WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys("vbnfvhbjnkmlkhfhgjiopijhgvbnm<");
        searchBox.submit();                                                                                
        test.log(Status.PASS, "Entered Invalid characters in the search field successfully");
        WebElement noResultsDiv = driver.findElement(By.xpath("//div[@class='a-section a-spacing-none']//span[contains(text(),'No results')]"));

        // Perform validation
        Assert.assertTrue(noResultsDiv.isDisplayed(), "No results message  displayed.");
        
        test.log(Status.PASS, "No results for invalid search is displayed successfully.");
        // Capture screenshot and log
        String screenshotPath = Screenshotutils.captureScreenshot(driver, "InValidSearchScreenshot");
        test.addScreenCaptureFromPath(screenshotPath);
        test.log(Status.INFO, "Screenshot captured: " + screenshotPath);

    }

}
