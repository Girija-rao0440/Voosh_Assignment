package Voosh.Assignment;
import org.apache.commons.io.FileUtils;

// Update with your actual package name

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class Screenshotutils {

    public static String captureScreenshot(WebDriver driver, String screenshotName) {
        String screenshotPath = "screenshots/" + screenshotName + ".png"; // Update the path as needed

        try {
            // Capture screenshot
            File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destination = new File(screenshotPath);
            FileUtils.copyFile(source, destination);
//            return screenshotPath;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return screenshotPath;
    }
}
