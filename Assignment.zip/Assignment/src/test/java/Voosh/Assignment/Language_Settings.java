package Voosh.Assignment;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Language_Settings extends Base {
	
	@Test
	public void testChangeLanguage() throws IOException {
	 driver.get("https://www.amazon.in/");
	   test = extent.createTest("Test Language setting ");
     WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	 try {
	 WebElement LanguageSelector = driver.findElement(By.id("icp-nav-flyout")); 
	 LanguageSelector.click();
	 test.log(Status.PASS, "Language selector clicked successfully");

	  

	  WebElement kannadaLabel = driver.findElement(By.xpath("//span[contains(text(),'ಕನ್ನಡ')]"));
      Actions actions = new Actions(driver);
      actions.moveToElement(kannadaLabel).click().perform();
      test.log(Status.PASS, "Kannada language has been selected");

     WebElement Submit=driver.findElement(By.xpath("//span[@class='a-button-inner']//input"));
     Submit.click();
     wait.until(ExpectedConditions.urlContains("language=kn_IN"));
     

  WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
  searchBox.sendKeys("ಪುಸ್ತಕ"); // Kannada for "book"
  searchBox.submit();

  // Capture a portion of the search results page (replace with suitable locator)
  WebElement searchResults = driver.findElement(By.xpath("//span[@class='a-color-state a-text-bold']"));

  // Verify if search results contain Kannada text (you can customize this verification)
  String searchResultsText = searchResults.getText();
  boolean containsKannada = searchResultsText.contains("ಪುಸ್ತಕ"); // Check for Kannada term
  Assert.assertTrue(containsKannada, "Search results do not contain Kannada text");
  test.log(Status.PASS, "Language update successfully and results are in selected language kannada");



     System.out.println("Language setting test passed!");
 } catch (Exception e) {
     e.printStackTrace();
     test.log(Status.FAIL, "Language setting test failed!");

     System.out.println("Language setting test failed!");
 }
	  String screenshotPath = Screenshotutils.captureScreenshot(driver, "language_selection_Screenshot");
      test.addScreenCaptureFromPath(screenshotPath);
      test.log(Status.INFO, "Screenshot captured: " + screenshotPath);
	}

}
