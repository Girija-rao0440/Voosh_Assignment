package Voosh.Assignment;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class Location extends Base {
	@Test
	 public void testLocationSelector() throws IOException {
		 driver.get("https://www.amazon.in/");
		   test = extent.createTest("Test Location selector");
		 WebElement location=driver.findElement(By.xpath("//a[@id='nav-global-location-popover-link']"));
		 location.click();
		 WebElement input=driver.findElement(By.xpath("//div[@id='GLUXZipInputSection']//div//input"));
		 input.clear();
         input.sendKeys("560092");
       
         WebElement applyButton = driver.findElement(By.xpath("//span[text()='Apply']"));
     
         JavascriptExecutor executor = (JavascriptExecutor) driver;
         executor.executeScript("arguments[0].click();", applyButton);
           test.log(Status.PASS, "Entered Pincode in the input field successfully");
//      
////		
         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
         String expectedText = "560092";
         boolean textUpdated = false;
         for (int attempt = 0; attempt < 10; attempt++) { 
             try {
                 WebElement locationText = driver.findElement(By.id("glow-ingress-line2"));
                 if (locationText.getText().contains(expectedText)) {
                     textUpdated = true;
                     break;
                 }
             } catch (Exception e) {
            	 System.err.println("Exception occurred: " + e.getMessage());
             }
             wait.withTimeout(Duration.ofSeconds(20)).pollingEvery(Duration.ofMillis(500)).until(ExpectedConditions.stalenessOf(applyButton));
         }

         if (textUpdated) {
             System.out.println("Pin code verification successful!");
             test.log(Status.PASS, "Pin code verification successful!");
         } else {
             System.out.println("Pin code verification failed.");
             test.log(Status.FAIL, "Pin code verification failed!");
         }
         
         String screenshotPath = Screenshotutils.captureScreenshot(driver, "Location_Updated_Screenshot");
         test.addScreenCaptureFromPath(screenshotPath);
         test.log(Status.INFO, "Screenshot captured: " + screenshotPath);
		 
	 }

}
