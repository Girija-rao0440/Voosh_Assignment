package Voosh.Assignment;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class EmptyCart extends Base {
	
	@Test
	public void testEmptyCart() throws IOException {
	 driver.get("https://www.amazon.in/");
	  test = extent.createTest("Test Empty Cart");
	 try {
	  WebElement cartIcon = driver.findElement(By.id("nav-cart")); 
      cartIcon.click();
      test.log(Status.PASS, "Cart Icon clicked successfully");
      WebElement emptyCartMessage = driver.findElement(By.xpath("//div[@class='a-row sc-your-amazon-cart-is-empty']//h2")); 

      Assert.assertEquals(emptyCartMessage.getText(), "Your Amazon Cart is empty");
      test.log(Status.PASS, "Verified Empty cart message displayed successfully");
      System.out.println("Empty cart test passed!");
      
  } catch (Exception e) {
      e.printStackTrace();
      System.out.println("Empty cart test failed!");
      test.log(Status.FAIL, " Empty cart message Failed");
  }
	  String screenshotPath = Screenshotutils.captureScreenshot(driver, "Empty_Cart_Screenshot");
      test.addScreenCaptureFromPath(screenshotPath);
      test.log(Status.INFO, "Screenshot captured: " + screenshotPath);

}
}
