package Voosh.Assignment;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.io.IOException;
import java.util.List;

public class SearchTest extends Base {

    @Test
    public void testSearchResultsDisplay() throws IOException {
        driver.get("https://www.amazon.in/");
         test = extent.createTest("Test valid search");

        WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys("laptop");
        searchBox.submit();
        test.log(Status.PASS, "Entered Laptop in the search field successfully");

        List<WebElement> searchResultTitles = driver.findElements(By.cssSelector("h2.a-size-mini a.a-link-normal"));

        Assert.assertTrue(searchResultTitles.size() > 0, "No search results found.");
       
        test.log(Status.PASS, "Search results were displayed successfully.");
        // Capture screenshot and log
        String screenshotPath = Screenshotutils.captureScreenshot(driver, "ValidSearchScreenshot");
        test.addScreenCaptureFromPath(screenshotPath);
        test.log(Status.INFO, "Screenshot captured: " + screenshotPath);
    }
    
    
}

